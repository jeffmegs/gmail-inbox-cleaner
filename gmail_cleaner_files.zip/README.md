# 📧 Gmail Inbox Cleaner (Python + Streamlit)

Clean up thousands of unwanted emails from your Gmail inbox — fast, safely, and in bulk.  
Includes both a **command-line tool** and a **Streamlit web app** with preview and filters.

---

## 🚀 Features

✅ Connects to Gmail via IMAP using App Password  
✅ Fetches 100,000+ emails with progress bar  
✅ Filters by **sender email** and **date range**  
✅ Deletes unwanted emails in bulk  
✅ Saves deleted email log to `deleted_emails.csv`  
✅ Streamlit UI for easy preview and delete  
✅ Secure (credentials not saved or stored)

---

## 🛠️ Setup Instructions

### 📦 One-line install (macOS/Linux)
```bash
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py && python3 get-pip.py && pip3 install streamlit pandas tqdm
```

### 🔧 Enable Gmail Access
1. Turn on IMAP: Gmail Settings > See All Settings > **Forwarding and POP/IMAP** > Enable IMAP  
2. Get App Password: [https://myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)

---

## ▶️ Run the Tool

### CLI Version
```bash
python gmail_inbox_cleaner.py
```

### Streamlit Version
```bash
streamlit run gmail_inbox_cleaner_ui.py
```

---

## ⚠️ Disclaimer
- This tool **permanently deletes emails**
- Always run a test with 2–3 messages first
- You must use a Gmail **App Password**, not your main login password
