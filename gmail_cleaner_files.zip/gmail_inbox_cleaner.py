import streamlit as st
import imaplib
import email
from email.header import decode_header
import pandas as pd
from datetime import datetime
from email.utils import parsedate_to_datetime

st.title("📧 Gmail Inbox Cleaner (Streamlit UI)")

def clean_subject(subject_raw):
    if subject_raw is None:
        return "(No Subject)"
    parts = decode_header(subject_raw)
    subject, encoding = parts[0]
    if isinstance(subject, bytes):
        return subject.decode(encoding or 'utf-8', errors='ignore')
    return subject

@st.cache_data(show_spinner=False)
def fetch_emails(email_address, app_password, sender_filter):
    imap = imaplib.IMAP4_SSL("imap.gmail.com")
    imap.login(email_address, app_password)
    imap.select("INBOX")
    status, messages = imap.search(None, "ALL")
    mail_ids = messages[0].split()

    data = []
    for eid in mail_ids:
        status, msg_data = imap.fetch(eid, "(RFC822)")
        for part in msg_data:
            if isinstance(part, tuple):
                msg = email.message_from_bytes(part[1])
                from_ = msg.get("From", "")
                subject = clean_subject(msg.get("Subject"))
                date_str = msg.get("Date", "")
                if sender_filter.lower() in from_.lower():
                    data.append((eid, from_, subject, date_str))
    imap.logout()
    return data

email_address = st.text_input("Gmail Address")
app_password = st.text_input("Gmail App Password", type="password")
sender_filter = st.text_input("Sender email to filter (e.g., newsletter@domain.com)")
cutoff_date = st.date_input("Delete emails before this date", datetime(2023, 1, 1))

if st.button("Fetch Emails"):
    if not email_address or not app_password or not sender_filter:
        st.warning("Please fill in all fields.")
    else:
        emails = fetch_emails(email_address, app_password, sender_filter)
        st.session_state.emails = emails
        st.success(f"Fetched {len(emails)} matching emails.")

if "emails" in st.session_state and st.session_state.emails:
    df = pd.DataFrame(st.session_state.emails, columns=["ID", "From", "Subject", "Date"])
    df["ParsedDate"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df[df["ParsedDate"] < pd.to_datetime(cutoff_date)]

    st.write(f"Found {len(df)} emails before cutoff date.")
    st.dataframe(df[["From", "Subject", "Date"]])

    if st.button("Confirm Delete Emails"):
        imap = imaplib.IMAP4_SSL("imap.gmail.com")
        imap.login(email_address, app_password)
        imap.select("INBOX")
        for eid in df["ID"]:
            imap.store(eid, '+FLAGS', r'\Deleted')
        imap.expunge()
        imap.logout()
        st.success(f"Deleted {len(df)} emails and logged out.")
